// ============================================================================
// RJL Magic Keys — application logic
//
// Handles: Supabase auth (email/password + Google OAuth), account
// activation (invite/recovery password setup), the live dashboard (TOTP key
// fetch + countdown, reveal/copy, section navigation, session activity log,
// live clock), and sign-out.
//
// Backend contract (do not change without updating the edge functions too):
//   - get-magic-key   : POST/GET, requires Authorization: Bearer <JWT>.
//                        Returns { site, code, step_seconds, expires_at,
//                        representative, position } or { error }.
//   - Auth             : Supabase email/password + Google OAuth (PKCE),
//                        session persisted in sessionStorage (tab-scoped,
//                        not localStorage — deliberate: shared/kiosk-style
//                        devices should not stay signed in across tabs).
// ============================================================================

// ---- Site config -----------------------------------------------------------
// NOT read from the database — magic_key_accounts has no address/device-id
// columns today. Edit these two values if the property or field unit ID
// ever changes. Everything else on the dashboard (account name, live key,
// representative name) comes from the API.
const SITE_CONFIG = {
  deviceId: "RJL-MK-01",
  addressLine1: "337 Settlement Road",
  addressLine2: "Thomastown, VIC 3074",
};

const SUPABASE_URL = "https://ifesjmdhlyurswgajslm.supabase.co";
const SUPABASE_PUBLISHABLE_KEY = "sb_publishable_2AetVTjWpPNPFkSAIYltWg_slgY9b1R";
const GET_MAGIC_KEY_URL = `${SUPABASE_URL}/functions/v1/get-magic-key`;

// ---- Supabase client ---------------------------------------------------
if (!window.supabase?.createClient) {
  throw new Error("Supabase client library failed to load.");
}

const supabase = window.supabase.createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: false, // handled explicitly in auth-callback.html for OAuth
    flowType: "pkce",
    storage: window.sessionStorage,
  },
});

// ============================================================================
// DOM references
// ============================================================================
const el = (id) => document.getElementById(id);

const authView = el("authView");
const dashboardView = el("dashboardView");
const loginPanel = el("loginPanel");
const setPasswordPanel = el("setPasswordPanel");

const loginForm = el("loginForm");
const emailInput = el("email");
const passwordInput = el("password");
const togglePasswordBtn = el("togglePassword");
const authMessage = el("authMessage");
const forgotBtn = el("forgotButton");
const googleBtn = el("googleSignInButton");

const setPasswordForm = el("setPasswordForm");
const newPasswordInput = el("newPassword");
const confirmPasswordInput = el("confirmPassword");
const setupMessage = el("setupMessage");

const loadingState = el("loadingState");
const errorState = el("errorState");
const errorText = el("errorText");
const retryBtn = el("retryButton");
const goSupportBtn = el("goSupportButton");
const dashboardContent = el("dashboardContent");

const keyDisplay = el("keyDisplay");
const keyDisplayLarge = el("keyDisplayLarge");
const keyExpiry = el("keyExpiry");
const keyExpiryBar = el("keyExpiryBar");
const revealBtn = el("revealButton");
const revealBtnAlt = el("revealButtonAlt");
const copyBtn = el("copyButton");
const copyBtnAlt = el("copyButtonAlt");

const siteNameEls = [el("siteName"), el("siteNameAlt")];
const repNameEl = el("repName");
const accessLevelEls = [el("accessLevel"), el("accessLevelAlt")];
const updatedAtEls = [el("updatedAt"), el("updatedAtAlt")];

const userMenuName = el("userMenuName");
const userMenuRole = el("userMenuRole");
const userMenuBtn = el("userMenuButton");
const userMenuPanel = el("userMenuPanel");
const signOutButton = el("signOutButton");

const navItems = Array.from(document.querySelectorAll(".nav-item[data-target]"));
const viewSections = Array.from(document.querySelectorAll(".view-section"));

const systemTimeEl = el("systemTime");
const activityList = el("activityList"); // dashboard sidebar — top 5
const activityListFull = el("activityListFull"); // Activity Log tab — full list
const activityViewAllBtn = el("activityViewAll");

const contactSupportBtn = el("contactSupportButton");

// ============================================================================
// Small helpers
// ============================================================================
function setMessage(node, text, success = false) {
  if (!node) return;
  node.textContent = text || "";
  node.classList.toggle("success", success);
}

function setButtonBusy(button, busy, busyLabel) {
  if (!button) return;
  button.disabled = busy;
  if (busy) {
    button.dataset.originalLabel = button.dataset.originalLabel || button.textContent;
    if (busyLabel) button.textContent = busyLabel;
  } else if (button.dataset.originalLabel) {
    button.textContent = button.dataset.originalLabel;
  }
}

function friendlyError(error, context) {
  const raw = (error?.message || String(error || "")).toLowerCase();
  if (raw.includes("invalid login credentials")) return "Incorrect email or password.";
  if (raw.includes("email not confirmed")) return "Confirm your email before signing in.";
  if (raw.includes("too many requests") || raw.includes("rate limit")) {
    return "Too many attempts. Wait a few minutes and try again.";
  }
  if (raw.includes("failed to fetch") || raw.includes("networkerror")) {
    return "Network error. Check your connection and try again.";
  }
  if (context === "login") return error?.message || "Sign in failed.";
  if (context === "key") return error?.message || "Could not load the live key.";
  return error?.message || "Something went wrong.";
}

function formatDigits(code) {
  if (!code) return "••• •••";
  return `${code.slice(0, 3)} ${code.slice(3)}`;
}

// ============================================================================
// Live system clock (sidebar) — Melbourne time, matches the property's
// timezone regardless of where the operator happens to be viewing from.
// ============================================================================
function startSystemClock() {
  const formatter = new Intl.DateTimeFormat("en-AU", {
    timeZone: "Australia/Melbourne",
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false,
    timeZoneName: "short",
  });

  function tick() {
    if (systemTimeEl) systemTimeEl.textContent = formatter.format(new Date()).toUpperCase();
  }
  tick();
  setInterval(tick, 1000);
}

// ============================================================================
// Session activity log — real client-side events (auth state changes, key
// reveals), newest first. Persisted per-tab in sessionStorage so a refresh
// doesn't lose it, but it never survives sign-out or a new session.
//
// This is NOT a query against magic_key_verification_attempts — no endpoint
// currently exposes that table to the client (by design; it has no RLS
// policies). If server-side history is wanted here later, that needs a new
// read-only edge function scoped to the caller's own account.
// ============================================================================
const ACTIVITY_STORAGE_KEY = "rjl.activity.log";
const ACTIVITY_ICONS = {
  success: "check",
  key: "key",
  login: "user",
  connection: "shield",
};

function loadActivity() {
  try {
    return JSON.parse(window.sessionStorage.getItem(ACTIVITY_STORAGE_KEY) || "[]");
  } catch {
    return [];
  }
}

function logActivity(icon, title, detail) {
  const entries = loadActivity();
  entries.unshift({ icon, title, detail, at: new Date().toISOString() });
  window.sessionStorage.setItem(ACTIVITY_STORAGE_KEY, JSON.stringify(entries.slice(0, 50)));
  renderActivity();
}

function relativeTime(iso) {
  const diffMs = Date.now() - new Date(iso).getTime();
  const mins = Math.round(diffMs / 60000);
  if (mins < 1) return "Just now";
  if (mins < 60) return `${mins} min ago`;
  const hrs = Math.round(mins / 60);
  if (hrs < 24) return `${hrs} hr ago`;
  return new Date(iso).toLocaleString("en-AU", { dateStyle: "medium", timeStyle: "short" });
}

function renderActivityInto(container, entries) {
  if (!container) return;
  container.innerHTML = "";
  if (entries.length === 0) {
    const empty = document.createElement("p");
    empty.className = "muted activity-empty";
    empty.textContent = "No activity yet this session.";
    container.appendChild(empty);
    return;
  }
  for (const entry of entries) {
    const row = document.createElement("div");
    row.className = "activity-item";
    row.innerHTML = `
      <span class="activity-icon activity-icon--${entry.icon}" aria-hidden="true"></span>
      <div class="activity-copy">
        <strong>${entry.title}</strong>
        <span>${entry.detail}</span>
      </div>
      <time>${relativeTime(entry.at)}</time>
    `;
    container.appendChild(row);
  }
}

function renderActivity() {
  const entries = loadActivity();
  renderActivityInto(activityList, entries.slice(0, 5)); // dashboard sidebar preview
  renderActivityInto(activityListFull, entries); // full Activity Log tab
  activityViewAllBtn?.classList.toggle("hidden", entries.length <= 5);
}

// "View all" just jumps to the full Activity Log tab — no local expand state.
activityViewAllBtn?.addEventListener("click", () => activateSection("activitySection"));

// Keep the "time ago" column fresh without re-fetching anything.
setInterval(renderActivity, 30000);

// ============================================================================
// Section navigation (Dashboard / Authorisation Key / Activity Log / Support)
// ============================================================================
function activateSection(targetId) {
  for (const section of viewSections) {
    section.classList.toggle("hidden", section.id !== targetId);
    section.classList.toggle("active-section", section.id === targetId);
  }
  for (const item of navItems) {
    item.classList.toggle("active", item.dataset.target === targetId);
  }
}

for (const item of navItems) {
  item.addEventListener("click", () => activateSection(item.dataset.target));
}

// ============================================================================
// Password visibility toggle
// ============================================================================
togglePasswordBtn?.addEventListener("click", () => {
  const isHidden = passwordInput.type === "password";
  passwordInput.type = isHidden ? "text" : "password";
  togglePasswordBtn.textContent = isHidden ? "Hide" : "Show";
});

// ============================================================================
// Auth: email/password sign in
// ============================================================================
loginForm?.addEventListener("submit", async (event) => {
  event.preventDefault();
  setMessage(authMessage, "");

  const email = emailInput.value.trim();
  const password = passwordInput.value;
  if (!email || !password) {
    setMessage(authMessage, "Enter your email and password.");
    return;
  }

  const submitBtn = loginForm.querySelector('button[type="submit"]');
  setButtonBusy(submitBtn, true, "Authenticating…");

  const { error } = await supabase.auth.signInWithPassword({ email, password });

  setButtonBusy(submitBtn, false);
  if (error) {
    setMessage(authMessage, friendlyError(error, "login"));
    return;
  }
  // onAuthStateChange (below) takes it from here.
});

// ---- Forgot password --------------------------------------------------
forgotBtn?.addEventListener("click", async () => {
  const email = emailInput.value.trim();
  if (!email) {
    setMessage(authMessage, "Enter your email address first, then select 'Forgot your password?'.");
    return;
  }
  setMessage(authMessage, "Sending password reset instructions…");
  const { error } = await supabase.auth.resetPasswordForEmail(email, {
    redirectTo: `${window.location.origin}/auth/callback`,
  });
  setMessage(
    authMessage,
    error ? friendlyError(error, "login") : "Check your email for a password reset link.",
    !error
  );
});

// ---- Google OAuth --------------------------------------------------------
let googleSignInInFlight = false;

googleBtn?.addEventListener("click", async () => {
  if (googleSignInInFlight) return;
  googleSignInInFlight = true;
  setButtonBusy(googleBtn, true, "Opening Google…");
  setMessage(authMessage, "Opening secure Google authentication…");

  try {
    const { data, error } = await supabase.auth.signInWithOAuth({
      provider: "google",
      options: {
        redirectTo: `${window.location.origin}/auth/callback`,
        skipBrowserRedirect: true,
        queryParams: { prompt: "select_account" },
      },
    });
    if (error) throw error;
    if (!data?.url) throw new Error("Google authentication did not return a secure redirect URL.");
    window.location.assign(data.url);
  } catch (error) {
    setMessage(authMessage, friendlyError(error, "login"));
    setButtonBusy(googleBtn, false);
    googleSignInInFlight = false;
  }
});

// Resume after auth-callback.html completes the OAuth code exchange.
async function resumeGoogleSessionIfReady() {
  const params = new URLSearchParams(window.location.search);
  const oauthError = params.get("oauth_error");
  if (oauthError) {
    setMessage(authMessage, oauthError);
    window.history.replaceState({}, document.title, window.location.pathname);
  }
  if (window.sessionStorage.getItem("rjl.oauth.ready") !== "1") return;
  window.sessionStorage.removeItem("rjl.oauth.ready");
  // onAuthStateChange fires once the session lands; nothing else needed here.
}

// ============================================================================
// Account setup (invite) / password recovery
// ============================================================================
function isSetupFlow() {
  const params = new URLSearchParams(window.location.search);
  const hashParams = new URLSearchParams(window.location.hash.replace(/^#/, ""));
  const type = params.get("type") || hashParams.get("type");
  return type === "invite" || type === "recovery";
}

function showSetupPanel() {
  loginPanel?.classList.add("hidden");
  setPasswordPanel?.classList.remove("hidden");
}

setPasswordForm?.addEventListener("submit", async (event) => {
  event.preventDefault();
  setMessage(setupMessage, "");

  const pw = newPasswordInput.value;
  const confirm = confirmPasswordInput.value;
  if (pw.length < 8) {
    setMessage(setupMessage, "Password must be at least 8 characters.");
    return;
  }
  if (pw !== confirm) {
    setMessage(setupMessage, "Passwords do not match.");
    return;
  }

  const submitBtn = setPasswordForm.querySelector('button[type="submit"]');
  setButtonBusy(submitBtn, true, "Activating…");

  const { error } = await supabase.auth.updateUser({ password: pw });

  setButtonBusy(submitBtn, false);
  if (error) {
    setMessage(setupMessage, friendlyError(error, "login"));
    return;
  }
  setMessage(setupMessage, "Account activated. Loading your dashboard…", true);
  window.history.replaceState({}, document.title, window.location.pathname);
});

// ============================================================================
// Dashboard: live TOTP key
// ============================================================================
let keyPollTimer = null;
let currentCode = null;
let keyRevealed = false;

function clearKeyPoll() {
  if (keyPollTimer) {
    clearInterval(keyPollTimer);
    keyPollTimer = null;
  }
}

function renderKey(code, revealed) {
  const display = revealed ? formatDigits(code) : "••• •••";
  if (keyDisplay) keyDisplay.textContent = display;
  if (keyDisplayLarge) keyDisplayLarge.textContent = display;
}

function updateExpiryUi(expiresAtIso, stepSeconds) {
  const totalMs = stepSeconds * 1000;
  const remainingMs = Math.max(0, new Date(expiresAtIso).getTime() - Date.now());
  const mins = Math.floor(remainingMs / 60000);
  const secs = Math.floor((remainingMs % 60000) / 1000);
  if (keyExpiry) keyExpiry.textContent = `${mins}:${String(secs).padStart(2, "0")}`;
  if (keyExpiryBar) keyExpiryBar.style.width = `${Math.max(0, Math.min(100, (remainingMs / totalMs) * 100))}%`;
  return remainingMs;
}

async function fetchMagicKey({ silent = false } = {}) {
  const { data: sessionData } = await supabase.auth.getSession();
  const token = sessionData?.session?.access_token;
  if (!token) throw new Error("Your session has expired. Sign in again.");

  const response = await fetch(GET_MAGIC_KEY_URL, {
    method: "GET",
    headers: {
      Authorization: `Bearer ${token}`,
      apikey: SUPABASE_PUBLISHABLE_KEY,
    },
  });

  const body = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(magicKeyErrorMessage(body?.error, response.status));
  }
  return body;
}

function magicKeyErrorMessage(code, status) {
  switch (code) {
    case "unauthorised":
      return "Your session has expired. Sign in again.";
    case "not_authorised_for_magic_key":
      return "Your account is not linked to a Magic Keys property.";
    case "key_inactive":
      return "This Magic Keys account is inactive. Contact RJL Commercial.";
    case "key_lookup_failed":
    case "membership_lookup_failed":
      return "The secure verification service is temporarily unavailable.";
    default:
      return status === 429
        ? "Too many attempts. Wait a few minutes and try again."
        : "Could not load your key. Try again.";
  }
}

async function loadDashboardKey({ silent = false } = {}) {
  clearKeyPoll();
  if (!silent) {
    loadingState?.classList.remove("hidden");
    errorState?.classList.add("hidden");
    dashboardContent?.classList.add("hidden");
  }

  try {
    const result = await fetchMagicKey();
    currentCode = result.code;

    for (const node of siteNameEls) if (node) node.textContent = result.site || "—";
    if (repNameEl) repNameEl.textContent = result.representative || "Authorised Representative";
    for (const node of accessLevelEls) if (node) node.textContent = result.position || "Authorised Representative";
    for (const node of updatedAtEls) {
      if (node) node.textContent = new Date().toLocaleString("en-AU", { dateStyle: "medium", timeStyle: "short" });
    }

    renderKey(currentCode, keyRevealed);

    let remainingMs = updateExpiryUi(result.expires_at, result.step_seconds);
    keyPollTimer = setInterval(() => {
      remainingMs = updateExpiryUi(result.expires_at, result.step_seconds);
      if (remainingMs <= 0) {
        // Step rolled over — fetch the new code silently (key stays revealed
        // if it already was, so the operator isn't interrupted mid-read).
        loadDashboardKey({ silent: true });
      }
    }, 1000);

    loadingState?.classList.add("hidden");
    errorState?.classList.add("hidden");
    dashboardContent?.classList.remove("hidden");
  } catch (error) {
    if (silent) return; // don't disrupt an already-visible dashboard on a background refresh failure
    loadingState?.classList.add("hidden");
    dashboardContent?.classList.add("hidden");
    if (errorText) errorText.textContent = friendlyError(error, "key");
    errorState?.classList.remove("hidden");
  }
}

function revealKey() {
  keyRevealed = true;
  renderKey(currentCode, true);
  logActivity(ACTIVITY_ICONS.success, "Authorisation key revealed", "Live key displayed to authorised user.");
}

async function copyKey() {
  if (!currentCode) return;
  try {
    await navigator.clipboard.writeText(currentCode);
    logActivity(ACTIVITY_ICONS.key, "Key copied", "Authorisation key copied to clipboard.");
  } catch {
    // Clipboard API can fail on non-secure contexts / older browsers — fall
    // back to revealing the key so the user can read and type it manually.
    revealKey();
  }
}

revealBtn?.addEventListener("click", revealKey);
revealBtnAlt?.addEventListener("click", revealKey);
copyBtn?.addEventListener("click", copyKey);
copyBtnAlt?.addEventListener("click", copyKey);
retryBtn?.addEventListener("click", () => loadDashboardKey());
goSupportBtn?.addEventListener("click", () => activateSection("supportSection"));

// ============================================================================
// Sign out
// ============================================================================
signOutButton?.addEventListener("click", async () => {
  clearKeyPoll();
  window.sessionStorage.removeItem(ACTIVITY_STORAGE_KEY);
  await supabase.auth.signOut();
  window.location.reload();
});

// ---- User menu (header) --------------------------------------------------
userMenuBtn?.addEventListener("click", () => {
  userMenuPanel?.classList.toggle("hidden");
});
document.addEventListener("click", (event) => {
  if (!userMenuPanel || userMenuPanel.classList.contains("hidden")) return;
  if (!userMenuBtn.contains(event.target) && !userMenuPanel.contains(event.target)) {
    userMenuPanel.classList.add("hidden");
  }
});

// ---- Support ---------------------------------------------------------
contactSupportBtn?.addEventListener("click", () => {
  window.location.href = "mailto:info@rjlcommercialgroup.com";
});

// ============================================================================
// View switching (auth <-> dashboard) + boot
// ============================================================================
function showDashboard(session) {
  authView?.classList.add("hidden");
  dashboardView?.classList.remove("hidden");
  keyRevealed = false;

  const name = session.user?.user_metadata?.full_name || session.user?.email || "Authorised User";
  if (userMenuName) userMenuName.textContent = name;
  if (userMenuRole) userMenuRole.textContent = session.user?.email || "";

  activateSection("dashboardSection");
  loadDashboardKey();
}

function showLogin() {
  dashboardView?.classList.add("hidden");
  authView?.classList.remove("hidden");
  clearKeyPoll();
}

let dashboardLoadedForUserId = null;

supabase.auth.onAuthStateChange((event, session) => {
  if (session && session.user) {
    if (dashboardLoadedForUserId !== session.user.id) {
      dashboardLoadedForUserId = session.user.id;
      logActivity(ACTIVITY_ICONS.login, "Signed in", session.user.email || "Authorised user");
      showDashboard(session);
    }
  } else {
    dashboardLoadedForUserId = null;
    showLogin();
  }
});

(async function boot() {
  startSystemClock();
  logActivity(ACTIVITY_ICONS.connection, "Secure connection established", "Encrypted session started.");
  renderActivity();

  if (isSetupFlow()) {
    showSetupPanel();
  }

  await resumeGoogleSessionIfReady();

  const { data } = await supabase.auth.getSession();
  if (data?.session) {
    dashboardLoadedForUserId = data.session.user.id;
    showDashboard(data.session);
  } else {
    showLogin();
  }
})();
